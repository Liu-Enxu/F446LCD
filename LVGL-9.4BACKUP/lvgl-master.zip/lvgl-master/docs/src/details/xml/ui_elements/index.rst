.. _xml_ui_elements:

===========
UI Elements
===========

.. toctree::
    :maxdepth: 2

    components
    widgets
    screens
    animations
    api
    consts
    events
    preview
    styles
    view
