.. include:: /include/external_links.txt
.. _editor_license:

=======
License
=======


LVGL Pro Editor comes with a simple, scalable and royalty-free licensing model that works
for open-source projects, startups, and enterprises alike.  `See all plans`_.
