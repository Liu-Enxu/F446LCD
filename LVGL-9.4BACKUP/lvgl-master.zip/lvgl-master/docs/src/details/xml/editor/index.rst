.. include:: substitutions.txt
.. _editor:

======
Editor
======


.. toctree::
    :maxdepth: 2

    overview
    install
    user_interface
    hotkeys
    license

