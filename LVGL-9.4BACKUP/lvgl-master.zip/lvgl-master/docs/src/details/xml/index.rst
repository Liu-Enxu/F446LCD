.. _editor_and_xml:

================
LVGL Pro and XML
================


.. toctree::
    :maxdepth: 2

    intro
    learn_by_examples
    editor/index
    xml/index
    integration/index
    ui_elements/index
    assets/index
    features/index
    tools/index
