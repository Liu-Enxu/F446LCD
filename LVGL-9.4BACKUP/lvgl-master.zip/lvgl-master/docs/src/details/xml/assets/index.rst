.. _xml_assets:

======
Assets
======

.. toctree::
    :maxdepth: 2

    images
    fonts

