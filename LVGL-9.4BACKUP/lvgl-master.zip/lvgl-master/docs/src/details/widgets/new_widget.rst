.. _new_widget:

==========
New Widget
==========
