.. _boards:

=============
Board Support
=============


.. toctree::
    :maxdepth: 2


    lvgl_supported
    partner_supported
    manufacturers/index
