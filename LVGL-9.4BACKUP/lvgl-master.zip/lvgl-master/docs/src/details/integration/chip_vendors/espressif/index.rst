.. _espressif:

=========
Espressif
=========

.. toctree::
    :maxdepth: 2

    overview
    add_lvgl_to_esp32_idf_project
    hardware_accelerator_dma2d
    hardware_accelerator_ppa
    tips_and_tricks
