===========
NXP PXP GPU
===========

API
***

.. API startswith:  lv_draw_pxp_

.. API startswith:  lv_pxp_
