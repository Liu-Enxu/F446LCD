.. _observer examples:

========
Examples
========

.. include:: ../../../examples/others/observer/index.rst

