#include "foo.h"

void foo_init(void)
{
}
